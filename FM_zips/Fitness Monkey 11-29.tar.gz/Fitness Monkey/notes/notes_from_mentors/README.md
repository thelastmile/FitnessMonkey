# FitnessMonkey
Fitness Monkey final project 

Team Members:
- Jen
- Julie
- Tulio
- Chris
